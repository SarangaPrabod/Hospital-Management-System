
import com.mysql.jdbc.Connection;
import java.sql.*;

public class MyConnection {

    public static Connection getConnection() {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/channeling_center","root","");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return con;

    }

}

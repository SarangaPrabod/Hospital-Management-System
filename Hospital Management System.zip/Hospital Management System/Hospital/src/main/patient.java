package main;



import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ~ Major_7th ~
 */
public class patient {
    
    public void InsertUpdateDeletePatient(String P_ID,String Name,String Address,String Email,String TP_no,String Gender,String DOB, int Age, char operation){
        Connection con =MyConnection.getConnection();
        PreparedStatement ps;
        if(operation == 'i'){
            try {
                ps=con.prepareStatement("INSERT INTO `patient`(P_ID,Name,Address,Email,TP_no,Gender,DOB,Age) VALUES (?,?,?,?,?,?,?,?)");
                ps.setString(1, P_ID);
                ps.setString(2, Name);
                ps.setString(3, Address);
                ps.setString(4, Email);
                ps.setString(5, TP_no);
                ps.setString(6, Gender);
                ps.setString(7, DOB);
                ps.setInt(8, Age);
                
                if(ps.executeUpdate()>0){
                    JOptionPane.showMessageDialog(null,"New Student Added");
                }
                
                
                
            } catch (SQLException ex) {
                Logger.getLogger(patient.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }

    void InsertUpdateDeletePatient(String P_ID, String Name, String Address, String Email, String TP_no, String Gender, String DOB, int ABORT, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void InsertUpdateDeletePatient(String P_ID, String Name, String Address, String Email, String TP_no, String Gender, String DOB) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void InsertUpdateDeletePatient(String P_ID, String Name, String Address, String Email, String TP_no, String Gender, java.util.Date DOB) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void InsertUpdateDeletePatient(char c, String P_ID, String Name, String Address, String Email, String TP_no, String Gender, String DOB) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void InsertUpdateDeletePatient(char c, Object object, String P_ID, String Name, String Address, String Email, String TP_no, String Gender, String DOB) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
